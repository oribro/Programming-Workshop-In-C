/**
 * @file MyString.c
 * @author  orib
 * @version 1.0
 * @date 28 Jul 2015
 *
 * @brief Program that counts appearances of substring in a string.
 *
 *
 * @section DESCRIPTION
 * There are 2 searching methods: 1) check until the end of the first string.
 *            2) check until the end of the first string and allow peeking
 *            in cycle to the beginning.
 * Input  : The string to search in, the substring to find inside,
 *          and a parameter to determine the search method.
 * Process: Search for the substring inside the string.
 * Output : The number of appearances of the substring in the string.
 */

// ------------------------------ includes ------------------------------
#include <stdio.h>

// -------------------------- const definitions -------------------------
/**
 * @def END_OF_STRING '\0'
 * @brief The end of a string.
 */
#define END_OF_STRING '\0'

/**
 * @def NOT_CYCLIC 0
 * @brief Search until the end of the string without cycles.
 */
#define NOT_CYCLIC 0

/**
 * @def CYCLIC 1
 * @brief Search until the end of the string with cycles.
 */
#define CYCLIC 1

/**
 * @def FIRST_CHAR 0
 * @brief The index of the first char in a string.
 */
#define FIRST_CHAR 0

/**
 * @def FALSE 0
 * @brief Bool replacement macro for false.
 */
#define FALSE 0

/**
 * @def TRUE 1
 * @brief Bool replacement macro for true. Used as increment to counter of appearances.
 */
#define TRUE 1

// ------------------------------ functions -----------------------------

// ------------------------------ declarations -----------------------------

/**
 * Counts the amount of str1 substrings that are equal to str2.
 * In case one (or two) of the strings is empty- returns 0.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @isCyclic != 0 - search also for cyclic appearance.
 * @isCyclic == 0 - search until the end of the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int countSubStr(const char* str1, const char* str2, int isCyclic);
/**
 * Counts the amount of str1 substrings that are equal to str2
 * while searching until the end of the string.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int substringLookup(const char* str1, const char* str2);
/**
 * Counts the amount of str1 substrings that are equal to str2
 * while searching also with cyclic peeking to the beginning of the string.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int cyclicSubstringLookup(const char* str1, const char* str2);
/**
 * @param str the string to find it's length.
 * @return the length of the given string (number of non-zero chars).
 */
int getStrLength(const char* str);

// ------------------------------ implementations -----------------------------

/**
 * @brief an example to a run of the program on a given input.
 * @return 0, to tell the system the execution ended without errors.
 */
int main()

{
    // Should print 1 because we read in a cyclic manner.
    printf("%d\n", countSubStr("abc", "abcabc", CYCLIC));
    return 0;
}

/**
 * Counts the amount of str1 substrings that are equal to str2.
 * In case one (or two) of the strings is empty- returns 0.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @isCyclic != 0 - search also for cyclic appearance.
 * @isCyclic == 0 - search until the end of the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int countSubStr(const char* str1, const char* str2, int isCyclic)
{
    // Checking for empty strings and null pointers.
    if (str1 == NULL || str2 == NULL || str1[FIRST_CHAR] == END_OF_STRING
        || str2[FIRST_CHAR] == END_OF_STRING)
    {
        return 0;
    }
    // Search until the end of str1.
    if (isCyclic == NOT_CYCLIC)
    {
        return substringLookup(str1, str2);
    }
        // After reaching the end of str1, allow the continuity of the search from str1[0].
    else
    {
        return cyclicSubstringLookup(str1, str2);
    }

}

/**
 * Counts the amount of str1 substrings that are equal to str2
 * while searching until the end of the string.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int substringLookup(const char* str1, const char* str2)
{
    unsigned int subStrAppearanceCounter = 0;
    // Variable for the first matched letter of the current search.
    int firstMatchedLetterIndex = 0;
    int i = 0, j = 0;
    while(str1[i] != END_OF_STRING)
    {
        // The first letters of the sub-strings are different so we need to search
        // deeper into str1. Search until a matched letter is found or we reached
        // the end of the string.
        while(str1[i] != str2[FIRST_CHAR] && str1[i] != END_OF_STRING)
        {
            i++;
        }
        // Reached the end of the string and didn't find a matched letter.
        if (str1[i] == END_OF_STRING)
        {
            return subStrAppearanceCounter;
        }
        // A first matched letter has been found. Keep the index for future search.
        firstMatchedLetterIndex = i;
        while((str1[i] == str2[j]) && (str1[i] != END_OF_STRING)
              && (str2[j] != END_OF_STRING))
        {
            i++;
            j++;
        }
        // A match of the substring is found since all the substring's letters
        // were matched.
        if (str2[j] == END_OF_STRING)
        {
            subStrAppearanceCounter++;
        }
        // Prepare for the next substring search.
        i = firstMatchedLetterIndex + 1;
        j = 0;
    }
    return subStrAppearanceCounter;
}

/**
 * Counts the amount of str1 substrings that are equal to str2
 * while searching also with cyclic peeking to the beginning of the string.
 * @str1 - the string
 * @str2 -  the substring to search in the string.
 * @return number appearance of str2 as substring of str1
 */
unsigned int cyclicSubstringLookup(const char* str1, const char* str2)
{
    // Get the length of the strings.
    int lengthOfStr1 = getStrLength(str1);
    int lengthOfStr2 = getStrLength(str2);
    // The number of times str2 appeared in str1.
    unsigned int subStrAppearanceCounter = 0;
    // Flag for checking for match between the substrings.
    int isMatched;
    // Indexes for the chars of the strings.
    int i, k;
    // Search str1.
    for (i = 0; i < lengthOfStr1; i++)
    {
        // Initialize searching parameters.
        k = 0;
        isMatched = TRUE;
        // Search str2 until the matching sequence is broken or we searched whole str2.
        while((k < lengthOfStr2) && isMatched)
        {
            // Check for identical chars. If we reached the end of str1 we will
            // return to the beginning of str1 using % operation.
            if(str2[k] != str1[(i + k) % lengthOfStr1])
            {
                // We found a letter that broke the sequence.
                isMatched = FALSE;
            }
            k++;
        }
        // Increase the counter if there was a match.
        subStrAppearanceCounter += isMatched;
    }
    return subStrAppearanceCounter;


}

/**
 * @param str the string to find it's length.
 * @return the length of the given string (number of non-zero chars).
 */
int getStrLength(const char* str)
{
    int length = 0;
    while (str[length] != END_OF_STRING)
    {
        length++;
    }
    return length;
}
